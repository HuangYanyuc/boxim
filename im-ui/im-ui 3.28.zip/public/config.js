// 'development': {
//     // # 接口请求地址
//     // # ws地址
//     VUE_APP_BASE_API: '/api',
//     VUE_APP_WS_URL: 'ws://localhost:8878/im'
// },
// 'production': {
//     // # 接口地址
//     // # ws地址
//     VUE_APP_BASE_API: 'http://im.loongson.cn/api',
//     VUE_APP_WS_URL: 'ws://im.loongson.cn:81/im'
// }

const url = {
    VUE_APP_BASE_API: '/api',
    VUE_APP_WS_URL: 'ws://im.loongson.cn/mini-box-im'
};

window.urlConfig = url