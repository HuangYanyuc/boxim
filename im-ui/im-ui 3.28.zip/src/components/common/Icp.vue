<template>
	<div class="icp">
<!--		<img class="icp-icon" src="../../assets/image/icp_logo.png">
		<a target="_blank"  href="https://beian.miit.gov.cn/">#</a>-->
	</div>
</template>

<script>
</script>

<style lang="scss">
	.icp {
		position: fixed;
		text-align: center;
		bottom: 20px;
		margin: 0 auto;
		width: 100%;
		color: #5c6b77;
		
		.icp-icon {
			width: 20px;
			height: 20px;
			vertical-align: bottom;
		}
	}
</style>